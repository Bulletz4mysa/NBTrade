namespace Easychart.Finance
{
    using System;

    public enum FormulaHitType
    {
        htNoWhere,
        htSize,
        htAxisX,
        htAxisY,
        htArea,
        htData
    }
}

