namespace Easychart.Finance
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void NativePaintHandler(object sender, NativePaintArgs e);
}

