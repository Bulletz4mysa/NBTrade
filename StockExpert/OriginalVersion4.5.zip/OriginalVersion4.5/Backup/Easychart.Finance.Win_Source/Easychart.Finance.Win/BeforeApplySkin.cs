namespace Easychart.Finance.Win
{
    using Easychart.Finance;
    using System;
    using System.Runtime.CompilerServices;

    public delegate void BeforeApplySkin(FormulaSkin fs);
}

