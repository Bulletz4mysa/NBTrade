namespace Easychart.Finance
{
    using System;

    public enum AxisPos
    {
        Left,
        Right
    }
}

