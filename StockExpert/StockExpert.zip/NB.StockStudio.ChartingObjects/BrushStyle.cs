namespace NB.StockStudio.ChartingObjects
{
    using System;

    public enum BrushStyle
    {
        Solid,
        Hatch,
        Linear,
        Empty
    }
}

