namespace NB.StockStudio.ChartingObjects
{
    using System;

    public enum SnapType
    {
        None,
        Price,
        Band
    }
}

