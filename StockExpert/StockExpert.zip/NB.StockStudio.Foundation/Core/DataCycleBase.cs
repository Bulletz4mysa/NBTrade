namespace NB.StockStudio.Foundation
{
    using System;

    public enum DataCycleBase
    {
        EVERY,
        SECOND,
        MINUTE,
        HOUR,
        DAY,
        WEEK,
        MONTH,
        QUARTER,
        HALFYEAR,
        YEAR
    }
}

