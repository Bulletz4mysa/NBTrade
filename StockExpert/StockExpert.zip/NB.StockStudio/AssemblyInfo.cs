using System.Diagnostics;
using System.Reflection;

[assembly: AssemblyCopyrightAttribute("Copyright 2003-2004 Adam Inc.")]
[assembly: AssemblyKeyNameAttribute("")]
[assembly: AssemblyKeyFileAttribute("")]
[assembly: AssemblyDelaySignAttribute(false)]
[assembly: AssemblyTrademarkAttribute("")]
[assembly: AssemblyConfigurationAttribute("")]
// [assembly: DebuggableAttribute(true, true)]
[assembly: AssemblyCompanyAttribute("Adam Inc.")]
[assembly: AssemblyProductAttribute("Stock Expert")]
[assembly: AssemblyDescriptionAttribute("")]
[assembly: AssemblyTitleAttribute("Stock Expert")]
[assembly: AssemblyAlgorithmIdAttribute(0x8004)]
[assembly: AssemblyVersionAttribute("1.1.1649.39150")]

