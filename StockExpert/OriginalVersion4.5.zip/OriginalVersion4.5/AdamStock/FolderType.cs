using System;

namespace StockExpert
{
    public enum FolderType
    {
        All = 0,

        Scan = 1,

        Exchange = 2,

        Favorite = 3,

        Industry = 4,

    }

}
