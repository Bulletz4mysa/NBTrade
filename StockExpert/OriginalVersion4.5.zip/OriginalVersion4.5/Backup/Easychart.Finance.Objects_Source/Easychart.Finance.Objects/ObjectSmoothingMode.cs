namespace Easychart.Finance.Objects
{
    using System;

    public enum ObjectSmoothingMode
    {
        Default,
        AntiAlias
    }
}

