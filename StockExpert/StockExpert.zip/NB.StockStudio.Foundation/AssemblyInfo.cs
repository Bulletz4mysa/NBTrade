// Assembly NB.StockStudio.Foundation, Version 2.1.1649.39149

[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyCompany("N&G Group Inc")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyCopyright("")]
[assembly: System.Reflection.AssemblyTitle("NB Stock Studio CoreLib")]
[assembly: System.Diagnostics.Debuggable(true, true)]
[assembly: System.Reflection.AssemblyProduct("NB Stock Studio Chart")]
[assembly: System.Reflection.AssemblyKeyName("")]
[assembly: System.Reflection.AssemblyKeyFile("")]
[assembly: System.Reflection.AssemblyDelaySign(false)]
[assembly: System.Reflection.AssemblyTrademark("")]

