namespace NB.StockStudio.Foundation
{
    using System;

    public enum Transform
    {
        Normal,
        FirstDataOfView,
        PercentView
    }
}

