namespace Easychart.Finance
{
    using System;

    public enum AxisLabelAlign
    {
        TickRight,
        TickCenter,
        TickLeft,
        Center
    }
}

