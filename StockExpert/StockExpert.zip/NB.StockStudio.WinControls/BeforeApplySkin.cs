namespace NB.StockStudio.WinControls
{
    using NB.StockStudio.Foundation;
    using System;
    using System.Runtime.CompilerServices;

    public delegate void BeforeApplySkin(FormulaSkin fs);
}

