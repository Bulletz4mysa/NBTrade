namespace NB.StockStudio.Foundation
{
    using System;

    public enum FormulaDot
    {
        NORMAL,
        CROSSDOT,
        POINTDOT,
        CIRCLEDOT
    }
}

