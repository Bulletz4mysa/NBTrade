namespace NB.StockStudio.ChartingObjects
{
    using System;

    public enum ImageType
    {
        FixedSize,
        Resizable,
        Rotate
    }
}

