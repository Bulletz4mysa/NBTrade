namespace NB.StockStudio.Foundation
{
    using System;

    public enum LatestValueType
    {
        None,
        StockOnly,
        All,
        Custom
    }
}

