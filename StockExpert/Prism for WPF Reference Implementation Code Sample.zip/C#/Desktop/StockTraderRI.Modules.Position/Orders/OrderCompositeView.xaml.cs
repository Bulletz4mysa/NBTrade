// Copyright (c) Microsoft Corporation. All rights reserved. See License.txt in the project root for license information.

using System.Windows.Controls;

namespace StockTraderRI.Modules.Position.Orders
{
    /// <summary>
    /// Interaction logic for OrderCompositeView.xaml
    /// </summary>
    public partial class OrderCompositeView : UserControl
    {
        public OrderCompositeView()
        {
            InitializeComponent();
        }
    }
}
