namespace NB.StockStudio.WinControls
{
    using System;

    public class Messages
    {
        public const int WM_CLOSE = 0x10;
        public const int WM_ERASEBKGND = 20;

        private Messages()
        {
        }
    }
}

