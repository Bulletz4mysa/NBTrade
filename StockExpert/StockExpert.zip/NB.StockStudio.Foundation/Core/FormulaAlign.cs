namespace NB.StockStudio.Foundation
{
    using System;

    public enum FormulaAlign
    {
        Center,
        Right,
        Left,
        ScreenCenter,
        ScreenUp,
        ScreenDown
    }
}

