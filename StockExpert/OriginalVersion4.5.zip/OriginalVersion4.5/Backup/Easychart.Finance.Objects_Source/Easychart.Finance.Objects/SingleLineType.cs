namespace Easychart.Finance.Objects
{
    using System;

    public enum SingleLineType
    {
        Vertical,
        Horizontal
    }
}

