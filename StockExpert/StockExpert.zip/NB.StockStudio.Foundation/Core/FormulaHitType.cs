namespace NB.StockStudio.Foundation
{
    using System;

    public enum FormulaHitType
    {
        htNoWhere,
        htSize,
        htAxisX,
        htAxisY,
        htArea,
        htData
    }
}

