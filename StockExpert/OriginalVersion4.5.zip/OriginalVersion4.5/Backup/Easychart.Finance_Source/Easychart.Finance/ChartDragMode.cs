namespace Easychart.Finance
{
    using System;

    public enum ChartDragMode
    {
        None,
        Axis,
        Chart
    }
}

