namespace NB.StockStudio.ChartingObjects
{
    using System;

    public enum Shape
    {
        ParralleloGram,
        Triangle
    }
}

