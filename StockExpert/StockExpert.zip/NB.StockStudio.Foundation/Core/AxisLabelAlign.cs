namespace NB.StockStudio.Foundation
{
    using System;

    public enum AxisLabelAlign
    {
        TickRight,
        TickCenter,
        TickLeft,
        Center
    }
}

