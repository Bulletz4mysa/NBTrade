namespace NB.StockStudio.Foundation
{
    using System;

    public enum FormulaType
    {
        Const,
        Array
    }
}

