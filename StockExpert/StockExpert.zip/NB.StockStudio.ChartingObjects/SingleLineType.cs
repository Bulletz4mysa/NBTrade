namespace NB.StockStudio.ChartingObjects
{
    using System;

    public enum SingleLineType
    {
        Vertical,
        Horizontal
    }
}

