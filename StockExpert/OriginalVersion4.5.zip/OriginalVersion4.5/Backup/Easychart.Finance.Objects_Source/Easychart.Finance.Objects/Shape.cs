namespace Easychart.Finance.Objects
{
    using System;

    public enum Shape
    {
        ParralleloGram,
        Triangle
    }
}

