namespace NB.StockStudio.Foundation
{
    using System;

    public class LunarInfo
    {
        public int Day;
        public int DayCyl;
        public bool IsLeap;
        public int Month;
        public int MonthCyl;
        public int Year;
        public int YearCyl;
    }
}

