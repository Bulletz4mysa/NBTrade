namespace Easychart.Finance
{
    using System;

    public enum VerticalAlign
    {
        VCenter,
        Top,
        Bottom
    }
}

