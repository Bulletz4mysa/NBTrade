// Copyright (c) Microsoft Corporation. All rights reserved. See License.txt in the project root for license information.

using System.Windows.Controls;

namespace StockTraderRI.Controls
{
    /// <summary>
    /// Interaction logic for RoundedBox.xaml
    /// </summary>
    public partial class RoundedBox : UserControl
    {
        public RoundedBox()
        {
            InitializeComponent();
        }
    }
}
