using System;

namespace StockExpert
{
    public enum ShortcutType
    {
        Stock = 0,

        Indicator = 1,

        Folder = 2,

    }

}
