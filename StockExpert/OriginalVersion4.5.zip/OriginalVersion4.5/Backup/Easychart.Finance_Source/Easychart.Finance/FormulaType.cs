namespace Easychart.Finance
{
    using System;

    public enum FormulaType
    {
        Const,
        Array
    }
}

