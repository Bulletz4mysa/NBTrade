using System;

namespace StockExpert
{
    public class Config
    {
		// Methods
		

    }

}
