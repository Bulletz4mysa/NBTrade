// Assembly Easychart.Finance, Version 2.1.1649.39149

[assembly: System.Reflection.AssemblyVersion("2.1.1649.39149")]
[assembly: System.Reflection.AssemblyCompany("Easychart Inc")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyCopyright("")]
[assembly: System.Reflection.AssemblyTitle("Easychart CoreLib")]
[assembly: System.Diagnostics.Debuggable(true, true)]
[assembly: System.Reflection.AssemblyProduct("Easy Financial Chart")]
[assembly: System.Reflection.AssemblyKeyName("")]
[assembly: System.Reflection.AssemblyKeyFile("")]
[assembly: System.Reflection.AssemblyDelaySign(false)]
[assembly: System.Reflection.AssemblyTrademark("")]

