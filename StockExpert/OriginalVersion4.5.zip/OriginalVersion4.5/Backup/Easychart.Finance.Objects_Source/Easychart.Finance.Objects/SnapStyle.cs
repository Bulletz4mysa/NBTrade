namespace Easychart.Finance.Objects
{
    using System;

    public enum SnapStyle
    {
        DateTime,
        BarsStart,
        BarsEnd,
        Screen,
        Chart
    }
}

