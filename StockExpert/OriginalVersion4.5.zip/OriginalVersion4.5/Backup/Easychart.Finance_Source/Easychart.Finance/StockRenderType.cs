namespace Easychart.Finance
{
    using System;

    public enum StockRenderType
    {
        Bar,
        Line,
        Candle
    }
}

