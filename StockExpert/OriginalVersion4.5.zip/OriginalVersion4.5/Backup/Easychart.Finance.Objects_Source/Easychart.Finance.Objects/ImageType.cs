namespace Easychart.Finance.Objects
{
    using System;

    public enum ImageType
    {
        FixedSize,
        Resizable,
        Rotate
    }
}

