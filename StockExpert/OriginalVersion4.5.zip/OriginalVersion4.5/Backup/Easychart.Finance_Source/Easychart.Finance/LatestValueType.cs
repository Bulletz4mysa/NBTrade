namespace Easychart.Finance
{
    using System;

    public enum LatestValueType
    {
        None,
        StockOnly,
        All,
        Custom
    }
}

