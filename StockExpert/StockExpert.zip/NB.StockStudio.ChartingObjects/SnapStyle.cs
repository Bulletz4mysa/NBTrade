namespace NB.StockStudio.ChartingObjects
{
    using System;

    public enum SnapStyle
    {
        DateTime,
        BarsStart,
        BarsEnd,
        Screen,
        Chart
    }
}

