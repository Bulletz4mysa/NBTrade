namespace NB.StockStudio.ChartingObjects
{
    using System;

    public enum CycleStyle
    {
        Equal,
        FabonacciCycle,
        Sqr,
        Symmetry
    }
}

