namespace Easychart.Finance
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void ViewChangedHandler(object sender, ViewChangedArgs e);
}

