namespace NB.StockStudio.Foundation.DataProvider
{
    using System;

    public class IntraDataManagerBase : DataManagerBase
    {
        public DateTime EndTime;
        public DateTime StartTime;
    }
}

