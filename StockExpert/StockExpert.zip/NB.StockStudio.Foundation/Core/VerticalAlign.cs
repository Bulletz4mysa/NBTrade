namespace NB.StockStudio.Foundation
{
    using System;

    public enum VerticalAlign
    {
        VCenter,
        Top,
        Bottom
    }
}

