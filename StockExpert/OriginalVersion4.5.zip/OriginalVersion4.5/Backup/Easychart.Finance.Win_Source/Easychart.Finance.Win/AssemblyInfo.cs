// Assembly Easychart.Finance.Win, Version 2.1.1649.39149

[assembly: System.Reflection.AssemblyVersion("2.1.1649.39149")]
[assembly: System.Reflection.AssemblyTitle("Easychart windows control")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Diagnostics.Debuggable(true, true)]
[assembly: System.Reflection.AssemblyKeyName("")]
[assembly: System.Reflection.AssemblyKeyFile("")]
[assembly: System.Reflection.AssemblyDelaySign(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("")]
[assembly: System.Reflection.AssemblyProduct("")]
[assembly: System.Reflection.AssemblyCompany("Easychart Inc")]
[assembly: System.Reflection.AssemblyConfiguration("")]

