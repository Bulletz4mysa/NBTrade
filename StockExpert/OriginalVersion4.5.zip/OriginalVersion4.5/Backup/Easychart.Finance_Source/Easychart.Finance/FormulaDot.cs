namespace Easychart.Finance
{
    using System;

    public enum FormulaDot
    {
        NORMAL,
        CROSSDOT,
        POINTDOT,
        CIRCLEDOT
    }
}

