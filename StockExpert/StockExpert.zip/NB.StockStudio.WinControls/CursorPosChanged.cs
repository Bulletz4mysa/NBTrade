namespace NB.StockStudio.WinControls
{
    using NB.StockStudio.Foundation;
    using NB.StockStudio.Foundation.DataProvider;
    using System;
    using System.Runtime.CompilerServices;

    public delegate void CursorPosChanged(FormulaChart Chart, int Pos, IDataProvider idp);
}

