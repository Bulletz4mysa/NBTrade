﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NB.StockStudio.Foundation.Valuation
{
    public static class FairValue
    {
        public static double GeomSeries (double startGrowthRate, int factor, int years)
        {
            double amount = 0;
            if (startGrowthRate == 1.0)
                amount = years + 1;
            else
                amount = (Math.Pow(startGrowthRate, years + 1) - 1) / (startGrowthRate - 1);

            if (factor >= 1)
                amount -= GeomSeries(startGrowthRate, 0, factor - 1);

            return amount;
        }

        public static double ReturnCompoundedAnnualRate(double presentValue, double futureValue, int year)
        {
            //compounded annual return
            return Math.Pow(futureValue / presentValue, 1.0 / year) - 1.0;
        }

        public static double FutureValue(double presentValue, double growthRate, int year)
        {
            return presentValue * Math.Pow(1 + growthRate, year);
        }

        public static double PresentValue(double futureValue, double interestRate, int year)
        {
            return futureValue * Math.Pow(1 + interestRate, -year);
        }

        public static double DiscountedCurrentValue (double eps, int years, double growthRate, double inflationRate, double bondRate )
        {
            var earningCashOfYears = eps * GeomSeries((1 + growthRate) / (1 + bondRate), 1, years);
            var v2 = FutureValue(eps, growthRate, years) * (1 + inflationRate) / (bondRate - inflationRate);
            var v = earningCashOfYears + PresentValue(v2, bondRate, years);
            return Math.Round(v, 2);
        }
    }


}
