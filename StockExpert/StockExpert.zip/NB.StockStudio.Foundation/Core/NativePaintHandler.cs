namespace NB.StockStudio.Foundation
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void NativePaintHandler(object sender, NativePaintArgs e);
}

