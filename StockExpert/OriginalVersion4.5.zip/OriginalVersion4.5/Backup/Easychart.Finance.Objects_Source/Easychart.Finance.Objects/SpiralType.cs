namespace Easychart.Finance.Objects
{
    using System;

    public enum SpiralType
    {
        Archimedes,
        Logarithmic,
        Parabolic,
        Hyperbolic,
        Lituus
    }
}

