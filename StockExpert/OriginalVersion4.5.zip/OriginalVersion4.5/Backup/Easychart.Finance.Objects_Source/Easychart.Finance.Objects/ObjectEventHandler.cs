namespace Easychart.Finance.Objects
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void ObjectEventHandler(object sender, BaseObject Object);
}

