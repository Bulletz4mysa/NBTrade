﻿// Decompiled with JetBrains decompiler
// Type: FML.SlowSTO
// Assembly: Basic_fml, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// MVID: E9284717-8834-4B37-BC08-9823918209B3
// Assembly location: E:\Development\TradingProjects\Easy Financial Chart3.5 .net 4.5\StockExpert\NB.StockStudio\bin\Debug\dllReference\formula\Basic_fml.dll

using NB.StockStudio.Foundation;
using NB.StockStudio.Foundation.DataProvider;

namespace FML
{
  public class SlowSTO : FormulaBase
  {
    private double N;
    private double M1;
    private double M2;

    public SlowSTO()
    {
        base.AddParam("N", 14.0, 1.0, 100.0);
        base.AddParam("M1", 3.0, 2.0, 50.0);
        base.AddParam("M2", 3.0, 2.0, 50.0);
    }

    public override FormulaPackage Run(IDataProvider dp)
    {
        this.DataProvider = dp;
        FormulaData formulaData = (base.CLOSE - FormulaBase.LLV(base.LOW, this.N)) / (FormulaBase.HHV(base.HIGH, this.N) - FormulaBase.LLV(base.LOW, this.N)) * 100.0;
        formulaData.Name = "A";
        FormulaData formulaData2 = FormulaBase.MA(formulaData, this.M1);
        formulaData2.Name = "K";
        FormulaData formulaData3 = FormulaBase.MA(formulaData2, this.M2);
        formulaData3.Name = "D";
        return new FormulaPackage(new FormulaData[]
			{
				formulaData2, 
				formulaData3
			}, "");
    }
  }
}
