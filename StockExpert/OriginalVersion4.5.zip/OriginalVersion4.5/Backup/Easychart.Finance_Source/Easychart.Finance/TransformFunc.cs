namespace Easychart.Finance
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate double TransformFunc(double d);
}

