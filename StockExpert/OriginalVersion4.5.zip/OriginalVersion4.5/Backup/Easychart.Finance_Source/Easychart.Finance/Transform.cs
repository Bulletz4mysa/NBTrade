namespace Easychart.Finance
{
    using System;

    public enum Transform
    {
        Normal,
        FirstDataOfView,
        PercentView
    }
}

