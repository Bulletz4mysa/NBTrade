namespace Easychart.Finance.Objects
{
    using System;

    public enum CycleStyle
    {
        Equal,
        FabonacciCycle,
        Sqr,
        Symmetry
    }
}

