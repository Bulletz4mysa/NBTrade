namespace NB.StockStudio.ChartingObjects
{
    using System;

    public enum SpiralType
    {
        Archimedes,
        Logarithmic,
        Parabolic,
        Hyperbolic,
        Lituus
    }
}

