// Assembly Win, Version 2.1.1649.39149

[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
[assembly: System.Reflection.AssemblyTitle("NB Stock Studio windows control")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Diagnostics.Debuggable(true, true)]
[assembly: System.Reflection.AssemblyKeyName("")]
[assembly: System.Reflection.AssemblyKeyFile("")]
[assembly: System.Reflection.AssemblyDelaySign(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("")]
[assembly: System.Reflection.AssemblyProduct("")]
[assembly: System.Reflection.AssemblyCompany("N&B Group Inc")]
[assembly: System.Reflection.AssemblyConfiguration("")]

