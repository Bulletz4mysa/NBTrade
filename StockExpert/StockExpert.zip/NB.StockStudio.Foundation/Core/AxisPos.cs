namespace NB.StockStudio.Foundation
{
    using System;

    public enum AxisPos
    {
        Left,
        Right
    }
}

