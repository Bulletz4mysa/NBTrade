namespace Easychart.Finance.Objects
{
    using System;

    public enum BrushStyle
    {
        Solid,
        Hatch,
        Linear,
        Empty
    }
}

