namespace Easychart.Finance
{
    using System;

    public enum StickAlignment
    {
        LeftTop,
        LeftCenter,
        LeftBottom,
        CenterTop,
        CenterCenter,
        CenterBottom,
        RightTop,
        RightCenter,
        RightBottom
    }
}

