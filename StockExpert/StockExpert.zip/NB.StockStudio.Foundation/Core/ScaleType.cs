namespace NB.StockStudio.Foundation
{
    using System;

    public enum ScaleType
    {
        Normal,
        Log,
        SquareRoot
    }
}

