namespace NB.StockStudio.Foundation
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate double TransformFunc(double d);
}

