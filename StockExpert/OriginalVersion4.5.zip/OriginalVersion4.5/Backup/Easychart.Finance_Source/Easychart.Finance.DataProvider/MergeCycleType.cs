namespace Easychart.Finance.DataProvider
{
    using System;

    public enum MergeCycleType
    {
        HIGH,
        LOW,
        OPEN,
        CLOSE,
        ADJCLOSE,
        SUM
    }
}

