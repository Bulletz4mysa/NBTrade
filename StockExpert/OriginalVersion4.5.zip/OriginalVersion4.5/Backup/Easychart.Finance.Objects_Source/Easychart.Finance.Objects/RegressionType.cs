namespace Easychart.Finance.Objects
{
    using System;

    public enum RegressionType
    {
        Channel,
        AsynChannel,
        StdChannel,
        StdErrorChannel,
        UpDownTrend
    }
}

